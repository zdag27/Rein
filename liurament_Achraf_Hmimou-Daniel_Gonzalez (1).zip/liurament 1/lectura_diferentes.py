"""
Grafica usando la formula de heaps usando los numeros reales de indexar la muestra los cuales luego usaremos para obtener los valores y graficar
"""

import matplotlib.pyplot as plt
"""
abrimos el fichero out.txt el cual es resultado de ejecutar 'python3 CountWordsWithFilter.py > out.txt' de tal manera que tenemos los valores de la muestra y trabajamos apartir de ellos
"""
with open('out.txt','r', encoding='utf-8') as f:
	lines=f.readlines()
total=len(lines)-2
"""
Preparamos los buffers necesarios para nuestra futura grafica
"""
x=[]
y=[]
diff=0
num=0
"""
recorremos linea por linea la salida de el CountWordsWithFilter.py adjuntando cuando una palabra es diferente y el numero de palabras que han aparecido hasta encontrar la siguiente palabra diferente
"""
for line in lines:
	lst=line.split(",")
	if(len(lst)==3):
		diff=diff+1
		num=num+int(lst[0])
		y.append(diff)
		x.append(num)
"""
Adjuntamos los valores que usamos como muestra de la grafica por si quiere revisarlos estos valores fueron los resultantes de un rand 
print (x[10000],y[10000]);
print (x[35000],y[35000]);
"""
print(total)
plt.plot(x,y)
plt.show()
