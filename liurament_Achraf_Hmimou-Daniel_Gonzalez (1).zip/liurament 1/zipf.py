"""
Este archivo toma los valores muestra que recopilamos aleatoriamente del resultado de imprimir por pantalla los valores de lectura_frecuencia.py y a traves de esto usa la formula de zipf para graficar todo apartir de dos valores reales
"""

import matplotlib.pyplot as plt
x=[]
y=[]
K=38804.76429
a=0.49
r=500

"""
a representa alpha
y el razonamiento de los valores se encuentra en el documento del lliurament
"""
while r<1000:
	y.append(K/(r**a))
	x.append(r)
	r=r+1
	print(r)
plt.plot(x,y)
plt.show()
