"""
Grafica usando la formula de zipf usando los numeros reales de indexar la muestra los cuales luego usaremos para obtener los valores y graficar
"""
import matplotlib.pyplot as plt
"""
abrimos el fichero out.txt el cual es resultado de ejecutar 'python3 CountWordsWithFilter.py > out.txt' de tal manera que tenemos los valores de la muestra y trabajamos apartir de ellos
"""
with open('out.txt','r', encoding='utf-8') as f:
	lines=f.readlines()
total=len(lines)-2
"""
Preparamos los buffers necesarios para nuestra futura grafica
"""
x=[]
y=[]
"""
recorremos linea por linea la salida de el CountWordsWithFilter.py adjuntando el apartado 0 y 2 del out.txt que reprecentan la frecuencia y el rango
"""
for line in lines:
	lst=line.split(",")
	if(len(lst)==3):
		y.append(int(lst[0]))
		x.append(int(lst[2].replace(" ","")))
"""
Adjuntamos los valores que usamos como muestra de la grafica por si quiere revisarlos estos valores fueron los resultantes de un rand 
print (x[26000],y[26000]);
print (x[18000],y[18000]);
"""
plt.plot(x,y)
plt.show()
