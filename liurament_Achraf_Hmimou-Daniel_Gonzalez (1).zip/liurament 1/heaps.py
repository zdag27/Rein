"""
Este archivo toma los valores muestra que recopilamos aleatoriamente del resultado de imprimir por pantalla los valores de lectura_diferencia.py y a traves de esto usa la formula de heaps para graficar todo apartir de dos valores reales
"""

import matplotlib.pyplot as plt
x=[]
y=[]
"""
b representa beta
y el razonamiento de los valores se encuentra en el documento del lliurament
"""
K=598.563
b=0.29872
n=15000
while n<18000:
	y.append(K*(n**b))
	x.append(n)
	n=n+1
	print(n)
plt.plot(x,y)
plt.show()
