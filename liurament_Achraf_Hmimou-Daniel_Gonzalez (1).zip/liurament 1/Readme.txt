Orden de ejecucion de los nuevos archivos.
1.->python3 IndexFiles.py --index inovels --path /path/to/novels
2.->python3 CountWordsWithFilter --index inovels > out.txt
3.->el resto de los scripts pueden ejecutarse de forma indiferente
	>python3 lectura_diferentes.py
	>python3 lectura_frecuencia.py
	>python3 heaps.py
	>python3 zipf.py
