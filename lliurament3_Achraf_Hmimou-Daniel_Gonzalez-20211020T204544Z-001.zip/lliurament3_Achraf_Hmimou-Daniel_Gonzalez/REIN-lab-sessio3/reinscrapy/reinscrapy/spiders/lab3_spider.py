import scrapy


class Lab3SpiderSpider(scrapy.Spider):
    name = 'lab3_spider'
    allowed_domains = ['books.toscrape.com']
    start_urls = ['http://books.toscrape.com']

    def parse(self, response):
        i=0
        print("entro parse")
        for book in response.css('article.product_pod'):
            print(i)
            i=i+1
            book_res = {}
            book_res['nombre'] = book.css('h3 a::text').extract_first()
            book_res['url'] = response.urljoin(book.css('h3 a::attr(href)').extract_first())
            book_res['imagen'] = 'books.toscrape.com'+'/'+book.css('div.image_container img::attr(src)').extract_first()
            book_res['puntuacion'] = book.css('p.star-rating::attr(class)').getall()[0].split(' ')[1] + ' of Five'
            yield scrapy.Request(book_res['url'], callback=self.detalles, meta=book_res)

        next = response.css('ul.pager li.next a::attr(href)').extract_first()
        print("------------- NEXT ---------------")
        if next is not None:
            # print('http://books.toscrape.com/'+'catalogue/'+next.replace("catalogue/",""))
            # next_page = 'http://books.toscrape.com/'+'catalogue/'+next.replace("catalogue/","")
            next_page = response.urljoin(next)
            print(next_page)
            yield scrapy.Request(next_page, callback=self.parse)
        print("------------- ENDNEXT ---------------")
    
    def detalles(self, response):
        detalle = response.meta
        detalle['descripcion'] =  response.css('article.product_page p::text').getall()[10]   
        detalle['categoria'] = response.css('ul.breadcrumb li a::text').getall()[-1]
        #detalle['categoria'] = detalle['categoria'][len(d)]
        for info in response.css('table tr'):
            detalle[info.css('th::text').extract_first()] = info.css('td::text').extract_first().replace('£','')
        
        yield detalle
        
            
